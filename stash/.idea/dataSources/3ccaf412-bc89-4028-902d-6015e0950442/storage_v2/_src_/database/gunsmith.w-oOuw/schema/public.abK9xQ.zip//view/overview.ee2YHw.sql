create view overview(id, name, total_allowed_attachments) as
WITH RECURSIVE reachable AS (SELECT weapon_data_1.id   AS weapon_id,
                                    attachment_data.id AS attachment_id
                             FROM weapon_data weapon_data_1
                                      JOIN weapon_slot_data ON weapon_data_1.id = weapon_slot_data.weapon_id
                                      CROSS JOIN LATERAL unnest(weapon_slot_data.allowed_attachment_ids) allowed_tarkov_id(allowed_tarkov_id)
                                      JOIN attachment_data
                                           ON attachment_data.tarkov_id::text = allowed_tarkov_id.allowed_tarkov_id::text
                             UNION
                             SELECT reachable_1.weapon_id,
                                    next_attachment.id
                             FROM reachable reachable_1
                                      JOIN attachment_slot_data
                                           ON attachment_slot_data.attachment_id = reachable_1.attachment_id
                                      CROSS JOIN LATERAL unnest(attachment_slot_data.allowed_attachment_ids) next_tarkov_id(next_tarkov_id)
                                      JOIN attachment_data next_attachment
                                           ON next_attachment.tarkov_id::text = next_tarkov_id.next_tarkov_id::text)
SELECT weapon_data.id,
       weapon_data.name,
       count(DISTINCT reachable.attachment_id) AS total_allowed_attachments
FROM weapon_data
         LEFT JOIN reachable ON reachable.weapon_id = weapon_data.id
GROUP BY weapon_data.id, weapon_data.name
ORDER BY (count(DISTINCT reachable.attachment_id)) DESC;

alter table overview
    owner to gunsmith;

